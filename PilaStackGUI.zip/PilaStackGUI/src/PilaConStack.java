import javax.swing.*;
import java.util.Stack;

public class PilaConStack {
    private Stack<String> pila;

    public PilaConStack() {
        pila = new Stack<>();
    }

    public void push(String elemento) {
        pila.push(elemento);
    }

    public String pop() {
        if (pila.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: La pila está vacía.");
            return null;
        } else {
            return pila.pop();
        }
    }

    public String peek() {
        if (pila.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: La pila está vacía.");
            return null;
        } else {
            return pila.peek();
        }
    }

    public boolean estaVacia() {
        return pila.isEmpty();
    }

    public void mostrarPila() {
        if (pila.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Error: La pila está vacía.");
        } else {
            StringBuilder contenido = new StringBuilder("Contenido de la pila:\n");
            for (String elemento : pila) {
                contenido.append(elemento).append("\n");
            }
            JOptionPane.showMessageDialog(null, contenido.toString());
        }
    }
}