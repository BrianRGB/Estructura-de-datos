import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaStack {
    private JTextField tfNom;
    private JButton enviarButton;
    private JButton desapilarButton;
    private JButton mostrarButton;
    private JPanel pPrincipal;
    private JTextPane pMostrar;
    private PilaConStack pilaConStack;

    public VistaStack() {
        pilaConStack = new PilaConStack();

        enviarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String elemento = tfNom.getText();
                pilaConStack.push(elemento);
                pMostrar.setText(pMostrar.getText() + elemento + "\n");
                tfNom.setText("");
            }
        });

        desapilarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String elemento = pilaConStack.pop();
                if (elemento != null) {
                    String textodeahorita = pMostrar.getText();
                    int lastIndex = textodeahorita.lastIndexOf("\n", textodeahorita.length() - 2);
                    if (lastIndex != -1) {
                        pMostrar.setText(textodeahorita.substring(0, lastIndex + 1));
                    } else {
                        pMostrar.setText("");
                    }
                }
            }
        });

        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pilaConStack.mostrarPila();
            }
        });


    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("VistaStack");
        frame.setContentPane(new VistaStack().pPrincipal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
